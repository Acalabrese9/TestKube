﻿namespace SimpleCalc.Services
{
    public interface ICalcService
    {
        int AddNumbers(int x, int y);
    }
}