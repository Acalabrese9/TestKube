# A simple ASP.NET Core Calculator  Application with Unit Tests

[![CircleCI](https://circleci.com/gh/daumie/dotnet-test-app.svg?style=svg)](https://circleci.com/gh/daumie/dotnet-test-app)

Simple ASP.NET Core calculator  application  with unit tests.
